#!/bin/bash
SERVER=`hostname`
VAR_1=$(date +%Y%m%d_%H%M)
_CMD_="collect-log.sh"
RHEL8_PATH="/home/ps_syssupp/OTPC_NET_Build-RH-Network/"
RHEL7_PATH="/home/syssupp/OTPC_NET_Build-RH-Network/"

if [[ -d "$RHEL8_PATH" ]]; then
    bash "${RHEL8_PATH}${_CMD_}" $VAR_1
elif [[ -d "$RHEL7_PATH" ]]; then
    bash "${RHEL7_PATH}${_CMD_}" $VAR_1
fi