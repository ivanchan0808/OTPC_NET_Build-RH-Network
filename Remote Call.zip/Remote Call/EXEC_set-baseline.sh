#!/bin/bash
_CMD_="set-baseline.sh"
RHEL8_PATH="/home/ps_syssupp/OTPC_NET_Build-RH-Network/"
RHEL7_PATH="/home/syssupp/OTPC_NET_Build-RH-Network/"

if [[ -d "$RHEL8_PATH" ]]; then
    bash "${RHEL8_PATH}${_CMD_}"
elif [[ -d "$RHEL7_PATH" ]]; then
    bash "${RHEL7_PATH}${_CMD_}"
fi