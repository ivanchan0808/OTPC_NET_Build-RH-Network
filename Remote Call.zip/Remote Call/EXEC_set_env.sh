#!/bin/bash

VERSION=`awk '{print $6}' /etc/redhat-release`
if [[ $VERSION == "release" ]]; then
    VERSION=`awk '{print $7}' /etc/redhat-release`
fi

if (( $(echo "$VERSION >= 8" | bc -l) )); then
    USER="ps_syssupp"
elif (( $(echo "$VERSION >= 7" | bc -l) )); then
    USER="syssupp"
fi

cd /home/${USER}/

wget http://pctmrep001/ks/sunny_ks/OTPC_NET_Build-RH-Network.tgz

tar -zxvf OTPC_NET_Build-RH-Network.tgz

chown -R $USER:$USER OTPC_NET_Build-RH-Network

if [[ -d "/home/${USER}/OTPC_NET_Build-RH-Network/" ]]; then
    echo "Setup Completed!"
else
    echo "/home/${USER}/OTPC_NET_Build-RH-Network/ not exist! Setup failed!"
fi

